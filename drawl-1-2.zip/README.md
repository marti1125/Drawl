# Drawl

A simple drawing app for Firefox OS.

## Credits

* https://github.com/Jaxo/fxosstub
* http://robnyman.github.com/Firefox-OS-Boilerplate-App/
* http://www.eyecon.ro/bootstrap-slider/
* http://tenderlovingcode.com/blog/web-apps/html5-canvas-drawing-on-ipad/
* http://getbootstrap.com/

## Contributors

* [Aaron Druck](https://www.whatthedruck.com/)
* [Maureen Hanratty](http://www.mhanratty.com)

